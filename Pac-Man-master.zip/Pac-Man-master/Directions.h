#pragma once

enum Direction
{
	Up = 1,
	Down = -1,
	Left = 2,
	Right = -2,
	Unset = 0
};